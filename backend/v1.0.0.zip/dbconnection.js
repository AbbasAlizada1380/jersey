import { Sequelize } from "sequelize";
import dotenv from "dotenv";

// Load environment variables from .env file
dotenv.config();

// Database configuration with defaults for development
const dbConfig = {
  database: process.env.DB_NAME || "jersey",
  username: process.env.DB_USER || "root",
  password: process.env.DB_PASS || "", // empty password for local development
  host: process.env.DB_HOST || "localhost",
  port: parseInt(process.env.DB_PORT) || 3306,
  dialect: "mysql",
  logging: process.env.NODE_ENV === "production" ? false : console.log,
  pool: {
    max: parseInt(process.env.DB_POOL_MAX) || 5,
    min: parseInt(process.env.DB_POOL_MIN) || 0,
    acquire: parseInt(process.env.DB_POOL_ACQUIRE) || 30000,
    idle: parseInt(process.env.DB_POOL_IDLE) || 10000,
  },
  retry: {
    max: parseInt(process.env.DB_RETRY_MAX) || 3,
  },
  dialectOptions: {
    connectTimeout: 60000,
  },
  timezone: process.env.DB_TIMEZONE || "+00:00",
};

// Create Sequelize instance
const sequelize = new Sequelize(
  dbConfig.database,
  dbConfig.username,
  dbConfig.password,
  {
    host: dbConfig.host,
    port: dbConfig.port,
    dialect: dbConfig.dialect,
    logging: dbConfig.logging,
    pool: dbConfig.pool,
    retry: dbConfig.retry,
    dialectOptions: dbConfig.dialectOptions,
    timezone: dbConfig.timezone,
  }
);

// Enhanced connection test with better error messages
const testConnection = async (maxRetries = 3, retryDelay = 2000) => {
  let retries = 0;

  while (retries < maxRetries) {
    try {
      await sequelize.authenticate();
      console.log("✅ Database connection established successfully.");
      console.log(`📊 Connected to database: ${dbConfig.database}`);
      return true;
    } catch (error) {
      retries++;
      console.error(
        `❌ Database connection attempt ${retries}/${maxRetries} failed:`,
        error.message
      );

      if (retries < maxRetries) {
        console.log(
          `🔄 Retrying connection in ${retryDelay / 1000} seconds...`
        );
        await new Promise((resolve) => setTimeout(resolve, retryDelay));
      } else {
        console.error("\n💥 All connection attempts failed!");
        console.error("🔧 Troubleshooting tips:");
        console.error("1. Check if MySQL server is running");
        console.error("2. Verify your database credentials in .env file");
        console.error("3. Ensure the database exists");
        console.error("4. Check if MySQL is on port 3306");
        throw error;
      }
    }
  }
};

// Connection management
let isConnected = false;

export const initializeDatabase = async () => {
  if (!isConnected) {
    try {
      await testConnection();
      isConnected = true;
    } catch (error) {
      console.error("💥 Database initialization failed");
      // Don't throw error to allow server to start without DB (for development)
      console.error("⚠️  Starting server without database connection");
    }
  }
  return sequelize;
};

// Graceful shutdown handling
process.on("SIGINT", async () => {
  console.log("\n🛑 Received SIGINT. Closing database connection...");
  try {
    await sequelize.close();
    console.log("✅ Database connection closed.");
    process.exit(0);
  } catch (error) {
    console.error("❌ Error closing database connection:", error);
    process.exit(1);
  }
});

export { sequelize };
export default sequelize;
